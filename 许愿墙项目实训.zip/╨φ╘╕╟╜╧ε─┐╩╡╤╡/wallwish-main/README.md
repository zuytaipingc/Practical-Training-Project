# wallwish
许愿墙


## 项目展示
![](https://img-blog.csdnimg.cn/becadbe688164ecc862c3d26342546f2.png)

![在这里插入图片描述](https://img-blog.csdnimg.cn/7eb2d7dea508490d840c701048c8b09b.png)


![在这里插入图片描述](https://img-blog.csdnimg.cn/df8ea529cd984f9a955a091c47e294c6.png)

密码默认是：szm

![在这里插入图片描述](https://img-blog.csdnimg.cn/68cffb0ed9f2421d98af2e85176f273c.png)


## 环境准备
![在这里插入图片描述](https://img-blog.csdnimg.cn/6146ec67d03d4c15ba068b4d34b1701a.png)

![在这里插入图片描述](https://img-blog.csdnimg.cn/34f4cf52cc414b5f96a8e62fb85dfd7a.png)

![在这里插入图片描述](https://img-blog.csdnimg.cn/4bede642adf9447baaa4e54c8dd11ae4.png)


![在这里插入图片描述](https://img-blog.csdnimg.cn/d0ba9c53f5da4029ab1cb92af85d2147.png)



如果GitHub 代码网络不稳定；


微信公众号@孙中明； 回复6005 获取代码和数据库文件
