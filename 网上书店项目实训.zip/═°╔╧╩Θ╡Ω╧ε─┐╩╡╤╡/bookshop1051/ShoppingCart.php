<?php
session_start();
if (! isset($_SESSION['userName'])) {
    header('Location:Login.php');
}
require_once 'Conn.php';
$productid = $_GET['productid']?? 001;
$count = $_GET['count']??0;
   // 定义SQL语句，查询用户购物车中是否已经存在该书籍
$sql = "select count(*) c from cart where username = '" . $_SESSION['userName'] . "' and productid = '" . $productid . "'";
$result = $db->query($sql);
$row = $result->fetch_assoc();
$totalNumber = $row["c"];
if ($totalNumber > 0) {
        // 购物车已经有这个书籍了，将数据库中该记录的数量加一
    $sql = "update cart set quantity = quantity+" . $count . " where  username = '" . $_SESSION['userName'] . "' and productid = '" . $productid . "'";
 } else {
        // 购物车中没有这个书籍，将该数据插入数据库中去
        // INSERT INTO cart (username,productid,NAME,listprice,quantity) (SELECT 'aaa','1',NAME,listprice,1 FROM product WHERE productid = '1');
        $sql = "insert into cart (username,productid,name,listprice,quantity) (select '" . $_SESSION['userName'];
        $sql = $sql . "','" . $productid . "',NAME,listprice,1 FROM product WHERE productid = '" . $productid . "');";
}
    // echo $sql;
    // 更新数据库
    $result = $db->query($sql);

$sql = "select productid,name,quantity,listprice from cart where username = '" . $_SESSION['userName'] . "'";
$result1 = $db->query($sql);
while ($row = $result1->fetch_assoc()){
    $list[]=$row;
}
$result = $db->query($sql);
$sql = "SELECT SUM(listprice*quantity) s FROM cart WHERE username = '" . $_SESSION['userName'] . "'";
$result2 = $db->query($sql);
$row2 = $result2->fetch_assoc();
$result->close();
$result2->close();
$db->close();

require "View/ShoppingCart.html";