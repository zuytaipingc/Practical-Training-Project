<?php
session_start(); // 启动会话
if (! isset($_SESSION['userName'])) {
    header('Location:Login.php');
}
require_once 'Conn.php';
// 查询数据库中的购物车记录，返回查询结果
$sql = "select productid,name,quantity,listprice from cart where username = '" . $_SESSION['userName'] . "'";
$result1 = $db->query($sql);
while ($row = $result1->fetch_assoc()){
    $list[]=$row;
}
$sql = "SELECT SUM(listprice*quantity) s FROM cart WHERE username = '" . $_SESSION['userName'] . "'";
$result2 = $db->query($sql);
$row2 = $result2->fetch_assoc();
// 查询用户信息
$sql = "SELECT  cname,country,province,city,address,zip,phone FROM account WHERE Username = '" . $_SESSION['userName'] . "'";
/*echo $sql;*/
$result = $db->query($sql);
$row = $result->fetch_assoc();
/*echo "<pre>";
print_r($row);*/
// 释放结果集
$result1->close();
$result2->close();
// 关闭连接
$db->close();
require "View/Checkout.html";