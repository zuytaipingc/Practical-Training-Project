<?php
session_start(); // 启动会话
// 如果未登录，没有设置Session变量“userName”，跳转到登录页
if (! isset($_SESSION['userName'])) {
    header('Location:Login.php');
}
require_once 'Conn.php';;
// 处理用户提交的原始数据
function checkInput($data)
{
    $data = trim($data); // 去除空格等不必要字符
    $data = stripslashes($data); // 删除反斜杠
    $data = htmlspecialchars($data); // 转义HTML特殊字符
    return $data;
}
// 判断是否通过提交表单进入的页面
if (isset($_POST['cName'])) {
    $cName = checkInput($_POST['cName']);
    $country = checkInput($_POST['country']);
    $province = checkInput($_POST['province']);
    $city = checkInput($_POST['city']);
    $address = checkInput($_POST['address']);
    $zip = checkInput($_POST['zip']);
    $phone = checkInput($_POST['phone']);
    $email = checkInput($_POST['email']);

    /* 将用户信息添加到account数据表 */
    $sql = "update account set cname = '$cName', country = '$country', province = '$province', city = '$city',address = '$address', zip = '$zip', phone = '$phone',email = '$email' ";
    $sql = $sql . " where username = '" . $_SESSION['userName'] . "'";
    $result = $db->query($sql);
    if ($result) {
        echo "<script>alert('保存成功！'); </script>";
    } else {
        echo "<script>alert('保存失败！'); </script>";
    }
}
// 显示用户信息
$sql = "SELECT  cname,country,province,city,address,zip,phone,email FROM account WHERE username = '" . $_SESSION['userName'] . "'";
$result = $db->query($sql);
$row = $result->fetch_assoc();

// 释放结果集
$result->close();
$db->close();
require "View/UserProfile.html";