<?php
session_start(); //启动会话

require_once 'Conn.php';
$cateid=$_GET['cateid']?? 1;
$page = $_GET['page'] ?? 1;
$perNumber=5; //每页显示的记录数
$startCount=($page-1)*$perNumber;
$result=$db->query("select productid,name,descn,image,listprice from product where categoryid = $cateid limit $startCount,$perNumber");
while ($row = $result->fetch_assoc()){
    $list[]=$row;
}

$result=$db->query("SELECT COUNT(*) c FROM product WHERE categoryid = ".$cateid); //获得记录总数
$row = $result->fetch_assoc();
$totalNumber=$row["c"];
$totalPage=ceil($totalNumber/$perNumber); //计算出总页数

$pageinfo='';

$pageinfo .= "<a href='Product.php?page=1'>首页</a>";
if($page != 1) {
    $prev = $page - 1;
    $pageinfo .= "<a href='Product.php?cateid=".$cateid."&page=".$prev."'>上一页</a>";
}

for ($i=1;$i<=$totalPage;$i++) {  //循环显示出页面;
    $pageinfo.="<a href='Product.php?cateid=".$cateid."&page=".$i."'>{$i}</a>";

}
if ($page<$totalPage) { //如果page小于总页数,显示下一页链接
    $next=$page + 1;
    $pageinfo.="<a href='Product.php?cateid=".$cateid."&page=".$next."'>下一页</a>";

}
if($page != $totalPage){
    $next = $page + 1;
    $pageinfo .= "<a href='Product.php?page={$next}'>下一页</a>";
}
$pageinfo .= "<a href='Product.php?page={$totalPage}'>末页</a>";
$result->close();
$db->close();
require "View/product.html";