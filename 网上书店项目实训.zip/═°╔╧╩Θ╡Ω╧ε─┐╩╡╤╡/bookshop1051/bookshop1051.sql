/*
SQLyog Ultimate v11.24 (32 bit)
MySQL - 5.7.17-log : Database - bookshop1051
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`bookshop1001` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `bookshop1051`;

/*Table structure for table `account` */

DROP TABLE IF EXISTS `account`;

CREATE TABLE `account` (
  `Username` varchar(256) NOT NULL,
  `Password` varchar(80) NOT NULL,
  `Cname` varchar(80) NOT NULL,
  `Country` varchar(80) NOT NULL,
  `Province` varchar(80) NOT NULL,
  `City` varchar(80) NOT NULL,
  `Address` varchar(80) NOT NULL,
  `Zip` varchar(80) NOT NULL,
  `Phone` varchar(80) NOT NULL,
  `Email` varchar(80) NOT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `account` */

insert  into `account`(`Username`,`Password`,`Cname`,`Country`,`Province`,`City`,`Address`,`Zip`,`Phone`,`Email`) values ('111','111','1','1','1','1','1','1','13245678945','123@163.com'),('222','222','222','2','222','22','2','2','2','2'),('小明','123456','小明','中国','河北','石家庄','友谊大街569号','050000','13245612432','xiaoming@163.com');

/*Table structure for table `cart` */

DROP TABLE IF EXISTS `cart`;

CREATE TABLE `cart` (
  `Username` varchar(256) CHARACTER SET utf8 NOT NULL COMMENT '用户名',
  `ProductId` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '书籍id',
  `Name` varchar(80) CHARACTER SET utf8 NOT NULL COMMENT '书籍名称',
  `ListPrice` decimal(18,2) NOT NULL COMMENT '书籍图片地址',
  `Quantity` int(50) NOT NULL COMMENT '书籍价格',
  PRIMARY KEY (`Username`,`ProductId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `cart` */

insert  into `cart`(`Username`,`ProductId`,`Name`,`ListPrice`,`Quantity`) values ('123','008','纳博科夫','23.59',2),('a123','001','it','34.00',2),('','001','it','34.00',1),('123','002','php','18.00',3),('123','006','我必须宽容','21.00',2),('222','003','奇迹集','19.99',1),('111','003','奇迹集','19.99',12),('','002','php','18.00',3),('','003','奇迹集','19.99',4),('222','002','php','18.00',2),('111','002','php','18.00',3),('111','005','寺山修司少女诗集','24.44',8),('小明','017','PHP基础教程','49.80',1),('小明','002','php','18.00',4);

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `CategoryId` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '书籍分类id',
  `Name` varchar(80) CHARACTER SET utf8 NOT NULL COMMENT '分类名称',
  `Descn` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '分类描述',
  `Image` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '描述图片文件路径',
  PRIMARY KEY (`CategoryId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `category` */

insert  into `category`(`CategoryId`,`Name`,`Descn`,`Image`) values ('1','It','计算机','it.jpg'),('2','PHP','计算机','php.jpg'),('3','奇迹集','诗集','qjj.jpg'),('4','轻声说再见','小说','qsszj.jpg'),('5','寺山修司少女诗集','小说','ssxssnsj.jpg'),('6','我必须宽容','小说','wbxkr.jpg'),('7','万物有时','小说','wwys.jpg'),('8','纳博科夫','小说','nbkf.jpg'),('9','金融财富','财经','jj.jpg'),('10','经验','财经','jy.jpg'),('11','灵魂只能独行','小说','lhzndx.jpg'),('12','恋物物语','小说','lwwy.jpg'),('13','wx','诗集','wx.jpg'),('14','小说集','诗集','xs.jpg'),('15','正直','小说','zz.jpg'),('16','自在的旅行','小说','zzdlx.jpg');

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `ProductId` varchar(80) CHARACTER SET utf8 NOT NULL COMMENT '书籍id',
  `CategoryId` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '书籍分类id',
  `Name` varchar(80) CHARACTER SET utf8 NOT NULL COMMENT '书籍名称',
  `Descn` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '书籍描述',
  `Image` varchar(80) CHARACTER SET utf8 NOT NULL COMMENT '书籍图片地址',
  `Listprice` decimal(18,2) NOT NULL COMMENT '书籍价格',
  PRIMARY KEY (`ProductId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `product` */

insert  into `product`(`ProductId`,`CategoryId`,`Name`,`Descn`,`Image`,`Listprice`) values ('001','1','it','计算机','it.jpg','34.00'),('002','2','php','计算机','php.jpg','18.00'),('003','3','奇迹集','文学','qjj.jpg','19.99'),('004','4','轻声说再见','文学','qsszj.jpg','26.66'),('005','5','寺山修司少女诗集','诗集','ssxssnsj.jpg','24.44'),('006','6','我必须宽容','文学','wbxkr.jpg','21.00'),('007','7','万物有时','文学','wwys.jpg','20.14'),('008','8','纳博科夫','小说','nbkf.jpg','23.59'),('009','9','金融财富','经济学','jj.jpg','27.66'),('010','10','经验','经济学','jy.jpg','19.99'),('011','11','灵魂只能独行','文学','lhzndx.jpg','25.68'),('012','12','恋物物语','文学','lwwy.jpg','34.58'),('013','13','wx','小说','wx.jpg','36.00'),('014','14','小说集','小说','xs.jpg','25.66'),('015','15','正直','小说','zz.jpg','23.68'),('016','16','自在的旅行','文学','zzdlx.jpg','26.68'),('017','2','PHP基础教程','计算机','phpjc.png','49.80');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
