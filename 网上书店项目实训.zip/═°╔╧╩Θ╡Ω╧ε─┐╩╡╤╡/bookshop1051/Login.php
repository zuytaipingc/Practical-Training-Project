<?php
//用户单击“登录”按钮返回页面，判断登录是否成功
if(isset($_POST["btnSubmit"])){
    $userName=$_POST["userName"];    //用户输入的用户名
    $pwd=$_POST["pwd"];    //用户输入的密码

    require_once 'Conn.php';
    $sql = "SELECT * FROM account WHERE Username='$userName' AND Password='$pwd'";
    $result = $db->query($sql);
    //登录成功
    if ($result->num_rows>=1){
        //使用Session保存登录的用户名信息
        session_start();   //启动会话
        $_SESSION['userName']=$_POST["userName"];

        //使用Cookie保存登录的用户名信息,保存30天
        setcookie("userName",$_POST["userName"], time()+60*60*24*30);

        $backUrl="Index.php";
        //若页面接收到了“frompage”参数传值，登录成功后跳转到“frompage”参数传递的网页文件地址
        if(isset($_GET["frompage"])){
            $backUrl=$_GET["frompage"].'.php';
        }
        //页面跳转
        echo "<script>window.location='{$backUrl}'</script>";
    }
    //登录失败，弹出提示框
    else{
        echo "<script>window.alert('用户名或密码错误！')</script>";
    }
}
include "View/login.html";

