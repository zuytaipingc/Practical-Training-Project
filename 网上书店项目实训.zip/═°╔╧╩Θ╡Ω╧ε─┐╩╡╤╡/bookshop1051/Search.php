<?php
session_start();
if($_POST){
    $booksearch = $_POST["booksearch"];
    require_once 'Conn.php';
// 定义SQL语句，按学号查询信息
    $sql = "SELECT Categoryid,Name,Descn,Image FROM category where Name='$booksearch' ;";
    //执行查询
    $result = $db->query($sql);
    while ($row = $result->fetch_assoc()) {
        $list[] = $row;
    }
    /* echo "<pre>";
     print_r($list);*/
    require "View/SearchResult.html";
    $result->free_result();
    $db->close();
}

else{
    require "View/Search.html";
}