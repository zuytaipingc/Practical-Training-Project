<?php
session_start(); // 启动会话
if (! isset($_SESSION['userName'])) {
    header('Location:Login.php');
}

require_once 'Conn.php';
$db->query("SET NAMES utf8");
// 书籍id
$productid = $_GET['productid'];

$sql = "delete from cart where username = '" . $_SESSION['userName'] . "' and productid = '" . $productid . "'";
$result = $db->query($sql);
if($result){
    header("Refresh:3;url=ShoppingCart.php");
    echo '删除成功！';
    exit;
}else{
    header("Refresh:3;url=ShoppingCart.php");
    echo '删除失败！';
    exit;
}