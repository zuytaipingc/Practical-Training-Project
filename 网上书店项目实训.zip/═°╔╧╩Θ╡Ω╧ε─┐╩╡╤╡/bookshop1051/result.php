<?php
include 'View/HeaderNav.html';
session_start(); // 启动会话
if (! isset($_SESSION['userName'])) {
    header('Location:Login.php');
}
require_once 'Conn.php';
$sql = "set @uname='".$_SESSION['userName']."'";
$db->query($sql);
$sql = "call checkout(@uname)";
$result = $db->query($sql);
echo "<div style='width: 500px;margin: 10px auto'>";
echo "<p><p>订单提交成功，感谢您的订购";
echo "<p>订单商品将开始配送，请保持您的联系方式畅通";
echo "<p>如对本订单有任何疑问，请联系我们的客服40000000000";
echo "<p>网上书城团队";
echo "<div>";
include 'View/Footer.html';


