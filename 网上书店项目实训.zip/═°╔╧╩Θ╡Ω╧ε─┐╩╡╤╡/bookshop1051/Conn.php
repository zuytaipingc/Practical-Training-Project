<?php
$db=new mysqli("localhost:3306", "root", "root", "bookshop1051");
// 检查连接 ,如果连接发生错误，退出脚本并显示提示信息
if ($db->connect_errno) {
    exit ("数据库连接失败。");
}
$db->query("SET NAMES utf8");
