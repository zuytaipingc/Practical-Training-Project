<?php
session_start();
unset($_SESSION['userName']); //释放userName Session变量
session_destroy();  //销毁会话中的全部数据
header("location:Index.php");
?>
