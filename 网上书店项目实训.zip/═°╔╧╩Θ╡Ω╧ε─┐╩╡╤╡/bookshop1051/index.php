<?php
require_once 'Conn.php';
$sql = "SELECT Categoryid,Name,Descn,Image FROM category ";
$result = $db->query($sql);
$list=[];
while ($row = $result->fetch_assoc())
{
    $list[]=$row;
}
/*print_r($list);*/
$result->close();
$db->close();
session_start(); // 启动会话
require "View/index.html";
